// Factory Pattern - GOF
// Produto abstrato
public abstract class TabletopAbstractProduct {
    public abstract String describe();
}
